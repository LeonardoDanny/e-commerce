<div class="container-fluid">
    <div class="alert alert-success">
        <p class="text-center align-middle">Selamat! Pesanan Anda Sudah Berhasil di Proses!</p>
    </div>
</div>



