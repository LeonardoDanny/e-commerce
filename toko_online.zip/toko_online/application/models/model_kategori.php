<?php

class Model_kategori extends CI_Model{
    public function data_action(){
        return $this->db->get_where("tb_barang", array('kategori' => 'action'));
    }

    public function data_horror(){
        return $this->db->get_where("tb_barang", array('kategori' => 'horror'));
    }

    public function data_sci_fi(){
        return $this->db->get_where("tb_barang", array('kategori' => 'sci fi'));
    }

    public function data_adventure(){
        return $this->db->get_where("tb_barang", array('kategori' => 'adventure'));
    }

    public function data_musical(){
        return $this->db->get_where("tb_barang", array('kategori' => 'musical'));
    }
}

?>