<?php
    class Kategori extends CI_Controller{

        public function __construct(){
            parent::__construct();
    
            if($this->session->userdata('role_id') != '2'){
                $this->session->set_flashdata('pesan','<div class="alert alert-danger alert-dismissible fade show" role="alert">
                <strong>Anda Belum Login! Silahkan Login Terlebih Dahulu!</strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
                </div>');
                redirect('auth/login');
            }
        }

        public function action(){
            $data['action'] = $this->model_kategori->data_action()->result();
            $this->load->view('templates/header');
            $this->load->view('templates/sidebar');
            $this->load->view('action', $data);
            $this->load->view('templates/footer');
        }

        public function horror(){
            $data['horror'] = $this->model_kategori->data_horror()->result();
            $this->load->view('templates/header');
            $this->load->view('templates/sidebar');
            $this->load->view('horror', $data);
            $this->load->view('templates/footer');
        }

        public function sci_fi(){
            $data['sci_fi'] = $this->model_kategori->data_sci_fi()->result();
            $this->load->view('templates/header');
            $this->load->view('templates/sidebar');
            $this->load->view('sci_fi', $data);
            $this->load->view('templates/footer');
        }

        public function adventure(){
            $data['adventure'] = $this->model_kategori->data_adventure()->result();
            $this->load->view('templates/header');
            $this->load->view('templates/sidebar');
            $this->load->view('adventure', $data);
            $this->load->view('templates/footer');
        }

        public function musical(){
            $data['musical'] = $this->model_kategori->data_musical()->result();
            $this->load->view('templates/header');
            $this->load->view('templates/sidebar');
            $this->load->view('musical', $data);
            $this->load->view('templates/footer');
        }
    }
?>